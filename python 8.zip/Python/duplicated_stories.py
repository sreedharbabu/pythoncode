from flask import Flask, render_template, request, jsonify
import openai
import json
import os
from flask_cors import CORS
from logs_info import log_message
import re
 
FLASK_ENV = 'testing'
app = Flask(__name__)
CORS(app)
 
# Reading the config.json file and storing the values in a variable
with open('config.json') as f:
    config = json.load(f)
 
openai.api_key = config["OPEN_AI_KEY"]
openai.api_type = config["API_TYPE"]
openai.api_base = config["API_BASE"]
openai.api_version = config["API_VERSION"]
deployment_name = config["DEPLOYMENT_NAME"]
model = config["MODEL"]
 
headers = {
    'api-key': openai.api_key,
    'Content-Type': 'application/json'
}
 
temperature = 0.65
top_p = 1
 
# Function to extract and strip summary from user stories
def extract_summaries(user_stories):
    summaries = []
    for story in user_stories:
        start_index = story.find('Summary: ')
        if start_index != -1:
            summary = story[start_index + len('Summary: '):].split('\n')[0]
            summaries.append(summary.strip())
    return summaries
 
# Function to find duplicated and new stories with original content from 'data'
# Function to find duplicated and new stories with original content from 'data'
 
def find_duplicated(linked_issue, data, user_id, uid):
    print("\n linked_issue :", linked_issue)
 
    # Split the data into individual user stories based on the delimiter
    user_stories = data.strip().split('------------------------------------------------------------------------------------')
    print("\n\n\n find_duplicated ::: user_stories ::", user_stories)
 
    # Remove any empty strings from the list
    user_stories = [story.strip() for story in user_stories if story.strip()]
    print(f"Total User Stories from data: {len(user_stories)}")
 
    # Extract summaries from user stories
    user_story_details = extract_story_details(user_stories)
    print("\nExtracted User Story Details:", user_story_details)
 
    # Parse linked_issue if it's a JSON string
    if isinstance(linked_issue, str):
        try:
            linked_issue = json.loads(linked_issue)
        except json.JSONDecodeError as e:
            return f"Error decoding JSON: {e}"
 
    # Extract issue summaries from linked_issue
    issue_summaries = []
    if isinstance(linked_issue, list):
        for issue in linked_issue:
            issue_summary = issue.get('summary', '').strip()
            issue_summaries.append(issue_summary)
            print("issue_summary :: ", issue_summary)
 
    # Initialize lists for detailed duplicated and new stories
    detailed_duplicated_stories = []
    detailed_new_stories = []
 
    for story_detail in user_story_details:
        story_summary = story_detail.get('Summary')
 
        if story_summary and story_summary in issue_summaries:
            detailed_duplicated_stories.append(story_detail)
        else:
            detailed_new_stories.append(story_detail)
 
    # Create JSON structure for output
    output_data = {
        'duplicate_stories': detailed_duplicated_stories or [{"useStory": "None"}],
        'new_stories': detailed_new_stories or [{"useStory": "None"}],
    }
 
    # Convert to JSON without newline characters
    json_output = json.dumps(output_data, separators=(',', ':'))
    print("\n\n json_output ::", json_output)
 
    # Log the result
    log_message(user_id, uid, f"duplicated stories and new stories: {json_output}")
 
    return json_output
 
def extract_story_details(user_stories):
    story_details = []

    for index, story in enumerate(user_stories, start=1):
        story_detail = {"useStory": f"User Story {index}"}

        # Extract fields based on the expected format
        story_detail["Summary"] = extract_field(r"Summary: (.+?)(\n|$)", story)
        story_detail["Description"] = extract_field(r"Description: (.+?)(\n|$)", story)
        story_detail["Technical_Details"] = extract_field(r"Technical Details: (.+?)(\n|$)", story)
        story_detail["Acceptance_Criteria"] = extract_field(r"Acceptance Criteria: (.+?)(\n|$)", story)
        story_detail["Sequence_of_execution_and_dependency"] = extract_field(
            r"Sequence of execution and dependency: (.+?)(\n|$)", story
        )

        story_details.append(story_detail)

    return story_details


def extract_field(pattern, text):
    """
    Extract the field based on the given regex pattern.
    Uses re.DOTALL to handle multiline fields.
    """
    print("\n\n\n pattern ::", pattern)
    print("\n\n\n text ::", text)
    match = re.search(pattern, text, re.DOTALL)
    print("\n\n\n match ::", match)
    return match.group(1).strip() if match else "Not Specified"

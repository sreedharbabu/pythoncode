from flask import Flask,Blueprint, render_template, request, jsonify
import openai
import os, re
import json
import requests
from flask_cors import CORS
from open_ai import openai_mocked_res
import urllib3
import sys
from requests.adapters import HTTPAdapter
from urllib3.poolmanager import PoolManager
import ssl
import uuid
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
from logs_info import log_message
from jira_handle import parse_user_stories
from jira_handle import create_jira_issue
from jira_handle import clean_data
from fetch_linked import fetch_linked_issue
from duplicated_stories import find_duplicated


app = Flask(__name__)
api_bp = Blueprint('api', __name__, url_prefix='/api')
FLASK_ENV='testing'
CORS(app)

global feature_id
# Store credentials temporarily in memory
credentials = {}

# Replace these with your Jira credentials and project details
JIRA_URL = 'https://advantagealm.atlassian.net/rest/api/latest/issue'
JIRA_AUTH = ('sruthiv@hcltech.com', 'ATATT3xFfGF0RsQ0V1dYM9P9IRFUBaVv3cp1SvBFayGcm9bTVWjIdrNQSMfJYTQTkgIKxbsEr_6knzvtVgVenMF9EMhClZUOBnCBYEyvuDXpuxHCA8ATECsUbPjGETz4ZzHW95AgRJFzd-08yNg63tP8-oAw-1if6nRGJQa90h2KsdeY8XvWXeg=63B65EE3')

PROJECT_KEY = '10284'  # Replace with your Jira project key

#patterns
userid_pattern = r'userid=(\w+)'


# def fetch_values(description):
#     # Declare that we want to use the global variables
#     global username, pswrd, projectid, projectkey, projectname, featureid

#    # Regular expressions to extract the required values
#     user_name = re.search(r'username:([^,]+)', description).group(1)
#     paswrd = re.search(r'password:([^,]+)', description).group(1)
#     project_id = re.search(r'projectid:([^,]+)', description).group(1)
#     project_key = re.search(r'projectkey:([^,]+)', description).group(1)
#     project_name = re.search(r'projectname:([^,]+)', description).group(1)
#     feature_id = re.search(r'featureid:([^,]+)', description).group(1)
#     globals.username= user_name 
#     globals.pswrd = paswrd
#     projectid = project_id
#     projectkey = project_key 
#     projectname = project_name
#     featureid = feature_id
#     print("username, pswrd, projectid, projectkey, projectname, featureid", username, pswrd, projectid, projectkey, projectname, featureid)

# # Define a route for the main page8
# @api_bp.route('/')
# def login():
#     return render_template('login.html')

# # Define a route for the main page8
#@api_bp.route('/feature')
@api_bp.route('/')
def index():
    return render_template('index.html')

@api_bp.route('/next')
def rewrite():
    return render_template('rewrite.html')

@api_bp.route('/step')
def step():
    return render_template('stepidentify.html')

@api_bp.route('/story')
def story():
    return render_template('userstory.html')

@api_bp.route('/jirapush')
def jira():
    return render_template('jirapush.html')


# Define a route to handle form submission and interaction with OpenAI
@api_bp.route('/get_login_credentials', methods=['POST'])
def get_login_credentials():
    data = request.json
    username = data.get('username')
    apitoken = data.get('apitoken')

    # Logic to validate or process the credentials
    # Here, we'll just create a dummy response
    if username == "admin" and apitoken == "secret":
        response = {
            'content': 'Login Successful',
            'role': 'Administrator'
        }
    else:
        response = {
            'error': 'Invalid credentials'
        }

    return jsonify(response)

# Define a route to handle form submission and interaction with OpenAI
@api_bp.route('/get_prompt_feature_analyze', methods=['POST'])
def get_prompt_feature_analyze():
    query = """Please identify the gaps in the given requirements and provide the suggestions to fill the gaps."""
    details = "analyze"
    data = request.get_json()
    description = data.get('description')
    summary = data.get('summary')
    #Extract user id
    match = re.search(userid_pattern, description)
    if match:
        user_id = match.group(1)
        print(f"Extracted userid: {user_id}")
    else:
        user_id = "NULL"
   
    # fetch_values(description)

    prompt =  summary + description  
    
    ask = """Please act as a product owner working for T-Mobile which is a large Telecom provider based out of North America 
and you are provided with high-level designs for a system change that needs to happen. 
This high-level design is provided by the customer architects in the form of a Jira feature. 
Your task is to do an analysis of the design details provided and identify any gaps or missing details. 
Please consider the following aspects which identify the gaps.
Any terms defined but not elaborated.
Any terms which are not understood by you.
Any gaps in the requirements 
Any detail provided that is not clear.
Any other suggestion.                                  
<jira-feature-details>
 """ + prompt + """ <jira-feature-details> """
    messages = [
    {"role": "system", "content": ask},    
    {"role": "user", "content": query}
    ]
    json_string = json.dumps(messages)
    uid = str(uuid.uuid4())
    log_message(user_id, uid, f"Request for Gap Analysys : {messages}")
    #call 2nd API to get open AI mocked up response
    data = openai_mocked_res(json_string,details, user_id, uid)
    status = data.get('status')
    response = data.get('content')
    print("\n \n status :: ", status)
    print("\n \n data :: ", data)
    print("\n \n response :: ", response)
    if status == 'success':
        return jsonify(response),200
    else:
        response = data.get('message')
        return jsonify(response),status

 
# Define a route to handle form submission and interaction with OpenAI
@api_bp.route('/get_prompt_feature_rewrite', methods=['POST'])
def get_prompt_feature_rewrite():
    details = "rewrite"
    query = """ Please help rewrite the inputs."""
    data = request.get_json()
    description = data.get('description')
    summary = data.get('summary')
    match = re.search(userid_pattern, description)
    if match:
        user_id = match.group(1)
        print(f"Extracted userid: {user_id}")
    else:
        user_id = "NULL"
    prompt =  summary + description  
    ask = """Please act as a product owner working for T-Mobile which is a large Telecom provider based out of North America 
and you are provided with high-level designs for a system change that needs to happen. 
This high-level design is provided by the customer's architects in the form of a Jira feature, in which various details are seprated by ---. 

Your task is to format and rewrite the inputs provided using the below guidelines
1. Please augment the writing with your expertise in the subject while rewriting the content.
2. Please use a US English dictionary.
3. Make use of moderately complex words.
4. Keep language simple and easy to read.
5. Please use a professional tone while rewriting.
6. Please add #ToDo where missing details can be added by the customer's technical architect.                                
<jira-feature-details>
 """ + prompt + """                   
</jira-feature-details> """
    messages = [
    {"role": "system", "content":  ask},    
    {"role": "user", "content": query}
    ]
    json_string = json.dumps(messages)
    uid = str(uuid.uuid4())
    log_message(user_id,uid, f"Request for Re-write : {messages}")
     #call 2nd API to get open AI mocked up response
    data = openai_mocked_res(json_string, details,user_id,uid)
    status = data.get('status')
    print("\n \n status :: ", status)
    response = data.get('content')
    print("\n \n response :: ", response)
    if status == 'success':
       pattern = r"<jira-feature-details>(.*?)</jira-feature-details>"
       match = re.search(pattern, response, re.DOTALL)
    
       if match:
        # Return the extracted text between the tags
            response = match.group(1).strip()
            return jsonify(response),200
       else:
            return None
    else:
        response = data.get('message')
        print("\n \n response :: ", response)
        return jsonify(response),status
 
# Define a route to handle form submission and interaction with OpenAI
@api_bp.route('/get_prompt_feature_stepidentify', methods=['POST'])
def get_prompt_feature_stepidentify():
    details = "stepidentify"
    query = """ Please help identify that tasks."""
    data = request.get_json()
    summary = data.get('summary')
    match = re.search(userid_pattern, summary)
    if match:
        user_id = match.group(1)
        print(f"Extracted userid: {user_id}")
    else:
        user_id = "NULL"
    prompt =  summary 
    ask = """Please act as a technical architect working for T-Mobile which is a large Telecom provider based out of North America
and you are provided with a high-level summary of a system change that needs to happen. 
Your task is to create technical tasks that need to be performed to complete the system change. 

While creating the task list please ensure that.
1. Every task is identified and listed.
2. Add prerequisite tasks also in case required. 
3. Add tasks to handle the alternate and exception scenarios as well.
4. Explain every task in descriptive manner in step-by-step.
5. Consider all technical details and their related actions also include integer values from jira-feature-details.
6. Look for term "ADF", if exists then create tasks otherwise skip this step.
7. Look for term "Control-M", if exists then create tasks otherwise skip this step.
                          
consider below mentioned points as well while creating tasks
1. Change analysis 
2. LLD 
3. Accessibility
4. Deployment
5. Release notes preparation Ops handoff 
6. Build and pipeline creation
7. Security scans and vulnerability fixes
8. Performance testing
9. Test documentation and Automation
10. UAT test Support
11. NOD Support and BVT
12. Environment Sync up (True up) activity    
                         
<jira-feature-details>
 """ + prompt + """                   
</jira-feature-details> """
    messages = [
    {"role": "system", "content": ask},    
    {"role": "user", "content": query}
    ]
    json_string = json.dumps(messages)
    uid = str(uuid.uuid4())
    log_message(user_id,uid, f"Request for Step Identify : {messages}")
    #call 2nd API to get open AI mocked up response
    data = openai_mocked_res(json_string, details, user_id, uid)
    status = data.get('status')
    print("\n \n status :: ", status)
    response = data.get('content')
    print("\n \n response :: ", response)
    if status == 'success':
        return jsonify(response),200
    else:
        response = data.get('message')
        print("\n \n response :: ", response)
        return jsonify(response)

# Define a route to handle form submission and interaction with OpenAI
@api_bp.route('/get_prompt_feature_userstory', methods=['POST'])
def get_prompt_feature_userstory():
    details = "userstory"
    query = """ Please create user stories."""
    data = request.get_json()
    summary = data.get('summary')   #Summary and Descrption updated 
    prompt =  summary #summary + description  

# Define regular expressions to match each section
    summary_pattern = r"Summary:\s*(.+)"
    tasks_pattern = r"tasks:(.+)$"    
    epicid_pattern = r'epicid:\s*([A-Z]+-\d+)'


# Extract summary
    summary_match = re.search(summary_pattern, prompt, re.IGNORECASE | re.DOTALL)
    summary = summary_match.group(1).strip() if summary_match else None

# Extract tasks
    tasks_match = re.search(tasks_pattern, prompt, re.IGNORECASE | re.DOTALL | re.MULTILINE)
    tasks = tasks_match.group(1).strip() if tasks_match else None
# Extract userid
    match = re.search(userid_pattern, summary)
    if match:
        user_id = match.group(1)
        print(f"Extracted userid: {user_id}")
    else:
        user_id = "NULL"  

    #Extract EPIC id
    match = re.search(epicid_pattern, summary)
    if match:
        epicid = match.group(1)
        print(f"EPIC ID : {epicid}")
    else:
        print(f"EPIC ID not found\n")

    partial_task = [tasks[i:i+5] for i in range(0, len(tasks),5)]
    for task in partial_task:
        ask = """Please assume the role of a product owner for T-Mobile, a prominent telecommunications provider based in North America. You have been given the following inputs that detail the necessary technical changes:
    Technical details provided as input in the Jira feature as .
High-level tasks that need to be executed for the technical change as .
Your task is to create user stories and include the following details for each identified user story:
    A1. Summary
2. Description
3. Technical Details - Be sure to extract all the technical details from the inputs, including any numerical values, and add them to this section in a descriptive manner.
4. Acceptance Criteria
5. Sequence of execution and dependency
Also, please add additional stories for:
1. Creation of a Low-Level Design Document
2. Customer approval of the Low-Level Design Document
3. DevOps and Release
4. Support and User Acceptance Testing (UAT)
5. Preparation of release notes and operational activity
When providing the list of user stories, please ensure:
1. You must provide all the user stories, without writing extra explanations.
2. All user stories contain the necessary details.
3. The list of user stories is sorted based on priority and dependency.
add '------------------------------------------------------------------------------------' after every Sequence of execution and dependency to separate.


<jira-feature-details>
 """ + summary  + """                   
</jira-feature-details> 

<tasks-list>
 """ + "".join(task) + """                    
</tasks-list>"""
    messages = [
    {"role": "system", "content": ask},    
    {"role": "user", "content": query}
    ]
    json_string = json.dumps(messages)
    uid = str(uuid.uuid4())
    print("\n------------------------------------------------------\n")
    log_message(user_id, uid, f"Request for User Story : {messages}")
    #call 2nd API to get open AI mocked up response
    user_story = openai_mocked_res(json_string, details, user_id, uid)
    status = user_story.get('status')
    data = user_story.get('content')
    print("\n \n user story status :: ", status)
    if status == 'success':
        print("\n\n\n\n epicid :: ", epicid)
        linked_issue = fetch_linked_issue( user_id, uid, epicid)
        #print("linked_issue", linked_issue)
        if isinstance(linked_issue, dict):
            status = linked_issue.get('status')        
            print("\n \n status :: ", status)
            log_message(user_id, uid, f"Linked issues : {linked_issue}")
            if(status):
                message = linked_issue.get('message')
            return jsonify(message,status) 
        dup_data = find_duplicated(linked_issue,data,user_id, uid)
        log_message(user_id, uid, f"duplicate stories : {dup_data}")
        if isinstance(user_story, str):
            userstorydata = {
               'user_Story': user_story
            }        
            #print("\n\n response from user story and duplicated " ,userstorydata, dup_data )
            return jsonify(userstorydata, dup_data),200
        else:
            userstorydata = {
               'User_Story': user_story
            }
            #print("\n\n response from user story and duplicated " ,userstorydata, dup_data )
    return jsonify(userstorydata, dup_data),200


#jirapush
@api_bp.route('/get_prompt_feature_jirapush', methods=['POST'])
def get_prompt_feature_jirapush():
    data = request.get_json()  
    epicid = data.get('epicid', 'Not Specified')

    # Safely access 'summary' and extract relevant fields
    newstories = data.get('summary', [])
    print("newstories ::", newstories)
    jira_ids = []
    for index, story in enumerate(newstories, start=1):
        summary = story.get("Summary", "")
        description = story.get("Description", "")
        tech_details = story.get("Technical_Details", "")
        acceptance_criteria = story.get("Acceptance_Criteria", "")
    
        print(f"Processing User Story {index}...\n")
        print(f"Summary: {summary}")
        print(f"Description: {description}")
        print(f"Technical Details: {tech_details}")
        print(f"Acceptance Criteria: {acceptance_criteria}\n")
    
    # Create a unique JIRA issue for each user story
        jira_id, status = create_jira_issue(summary, description, tech_details, acceptance_criteria, epicid)
        if jira_id:
            jira_ids.append(jira_id)
            print(f"Created JIRA issue for User Story {index}: {jira_id}")
        else:
            print(f"Failed to create JIRA for User Story {index} with error code {status}")

# Prepare JSON response with all JIRA IDs
    data = {f"User Story {index}": jira_id for index, jira_id in enumerate(jira_ids, start=1)}
    json_response = json.dumps(data)
    print("\nJIRA Issue Creation Results:\n", json_response)
    return jsonify(json_response),200

app.register_blueprint(api_bp)

# if __name__ == '__main__':
#     app.run(host="0.0.0.0", port=5000, debug=True)

if __name__ == '__main__':
    app.run(debug=True)

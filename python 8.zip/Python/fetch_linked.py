import requests
from requests.auth import HTTPBasicAuth
import json
from logs_info import log_message


# Replace these with your Jira credentials and project details
#JIRA_URL = 'https://advantagealm.atlassian.net/rest/agile/latest/epic/TGP-744/issue'
JIRA_AUTH = ('sruthiv@hcltech.com', 'ATATT3xFfGF0RsQ0V1dYM9P9IRFUBaVv3cp1SvBFayGcm9bTVWjIdrNQSMfJYTQTkgIKxbsEr_6knzvtVgVenMF9EMhClZUOBnCBYEyvuDXpuxHCA8ATECsUbPjGETz4ZzHW95AgRJFzd-08yNg63tP8-oAw-1if6nRGJQa90h2KsdeY8XvWXeg=63B65EE3')

# Replace these variables with your details
#JIRA_URL = 'https://your-domain.atlassian.net'
USERNAME = 'sruthiv@hcltech.com'
API_TOKEN = 'ATATT3xFfGF0RsQ0V1dYM9P9IRFUBaVv3cp1SvBFayGcm9bTVWjIdrNQSMfJYTQTkgIKxbsEr_6knzvtVgVenMF9EMhClZUOBnCBYEyvuDXpuxHCA8ATECsUbPjGETz4ZzHW95AgRJFzd-08yNg63tP8-oAw-1if6nRGJQa90h2KsdeY8XvWXeg=63B65EE3'
EPIC_KEY = 'TGP-676'



# Headers for the request
headers = {
    'Accept': 'application/json'
}

def fetch_linked_issue( user_id, uid, epicid):
    print("\n\n fetch_linked_issue : epicid :: ", epicid)
    
    JIRA_URL = f'https://advantagealm.atlassian.net/rest/agile/latest/epic/{epicid}/issue'    
    #JIRA_URL = 'https://advantagealm.atlassian.net/rest/agile/latest/epic/{epicid}/issue'
    print("\n\n JIRA_URL:", JIRA_URL)
    # Make the GET request
    response = requests.get(
        JIRA_URL,
        headers=headers,
        auth=HTTPBasicAuth(USERNAME, API_TOKEN),
        verify = False
    )
    # List to store issues
    linked_issues = []
    linked_issue = []
# Check if the request was successful
    if response.status_code == 200:
        issues = response.json()['issues']
        for issue in issues:
            linked_issues.append({
                'issue_key': issue['key'],
                'summary': issue['fields']['summary'],
                'description': issue['fields']['description']
            })
    else:
        # Create a dictionary with status code and text
        result = {
            "status": response.status_code,
            "message": response.text
        }

        print(f"Failed to fetch issues: {response.status_code} - {response.text}")
        return result

    linked_issues_str = json.dumps(linked_issues)
    
    # Print stored issues
    for issue in linked_issues:
        linked_issue = f"Issue Key: {issue['issue_key']}, Summary: {issue['summary']}, Description: {issue['description']}"
        log_message(user_id, uid, f"Linked issues of EPIC : {linked_issue}")
    return  linked_issues_str



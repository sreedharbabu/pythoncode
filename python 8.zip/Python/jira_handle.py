from flask import Flask,Blueprint, render_template, request, jsonify
import openai
import os, re
import json
import requests
from flask_cors import CORS
from open_ai import openai_mocked_res
import urllib3
import sys
from requests.adapters import HTTPAdapter
from urllib3.poolmanager import PoolManager
import ssl
import uuid
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
from logs_info import log_message

# Replace these with your Jira credentials and project details
JIRA_URL = 'https://advantagealm.atlassian.net/rest/api/latest/issue'
JIRA_AUTH = ('sruthiv@hcltech.com', 'ATATT3xFfGF0RsQ0V1dYM9P9IRFUBaVv3cp1SvBFayGcm9bTVWjIdrNQSMfJYTQTkgIKxbsEr_6knzvtVgVenMF9EMhClZUOBnCBYEyvuDXpuxHCA8ATECsUbPjGETz4ZzHW95AgRJFzd-08yNg63tP8-oAw-1if6nRGJQa90h2KsdeY8XvWXeg=63B65EE3')

#PROJECT_KEY = '10284'  # Replace with your Jira project key




# Define a custom SSLAdapter to ignore SSL errors
class SSLAdapter(HTTPAdapter):
    def init_poolmanager(self, *args, **kwargs):
        context = ssl.create_default_context()
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE
        kwargs['ssl_context'] = context
        return super().init_poolmanager(*args, **kwargs)

# Replace requests' default HTTPAdapter with the custom SSLAdapter
requests.Session().mount('https://', SSLAdapter())
#######*************************************************
# # Function to parse user stories from the data string


# Define a custom SSLAdapter to ignore SSL errors

# Function to create JIRA issue via REST API
def create_jira_issue(summary, description, tech_details, acceptance_criteria, epicid):
    url = JIRA_URL
    headers = {
        "Content-Type": "application/json"
    }
    auth = JIRA_AUTH
    bold_text = "**Acceptance Criteria :**"
    criteria = f"\n\n {bold_text}{acceptance_criteria}"
    bold_text = "**Technical Details :**"
    tech = f"\n\n {bold_text}{tech_details}"

    payload = {
        "fields": {
            "project": {
                "id": "10284",
                "key": "TGP",
                "name": "TMO-GenAI POC"
            },
            "parent": {
                "key": epicid
            },
            "summary": summary,
            "description": description + tech + criteria,
            "issuetype": {
                "name": "Story"
            }
        }
    }

    response = requests.post(url, headers=headers, auth=auth, json=payload, verify=False)
    if response.status_code == 201:
        return response.json()['key'], response.status_code
    else:
        return None, response.status_code

# Function to parse user stories and extract relevant data
def parse_user_stories(data):
    user_stories = []
    index = 1
    while True:
        # Find the next occurrence of "User Story X:" if it exists
        story_marker = f"User Story {index}:"
        start_index = data.find(story_marker)
        if start_index == -1:
            break
       
        # Find end of the current user story
        next_story_marker = f"User Story {index + 1}:"
        end_index = data.find(next_story_marker)
        if end_index == -1:
            end_index = len(data)
       
        # Extract current user story
        current_story_data = data[start_index:end_index].strip()
       
        # Extract summary, description, acceptance criteria
        summary_start_index = current_story_data.find("Summary:") + len("Summary:")
        summary_end_index = current_story_data.find("Description:")
        summary = current_story_data[summary_start_index:summary_end_index].strip()

        description_start_index = summary_end_index + len("Description:")
        description_end_index = current_story_data.find("Technical Details:")
        description = current_story_data[description_start_index:description_end_index].strip()

        tech_details_start_index = description_end_index + len("Technical Details:")
        tech_details_end_index = current_story_data.find("Acceptance Criteria:")
        tech_details = current_story_data[tech_details_start_index:tech_details_end_index].strip()

        acceptance_criteria_start_index = tech_details_end_index + len("Acceptance Criteria:")
        acceptance_criteria_end_index = current_story_data.find("Sequence of execution and dependency:")
        acceptance_criteria = current_story_data[acceptance_criteria_start_index:acceptance_criteria_end_index].strip()

        # Prepare story dictionary
        story_dict = {
            "summary": summary,
            "description": description,
            "technical_details": tech_details,
            "acceptance_criteria": acceptance_criteria
        }
        user_stories.append(story_dict)
       
        # Move to the next index
        index += 1
   
    return user_stories

# Function to clean parsed data
def clean_data(data):
    keys_to_keep = ['summary', 'description', 'technical_details', 'acceptance_criteria']
   
    for item in data:
        for key in keys_to_keep:
            if key in item:
                item[key] = item[key].replace('\\"', '').replace('",', '').strip()
   
    return data
class SSLAdapter(HTTPAdapter):
    def init_poolmanager(self, *args, **kwargs):
        context = ssl.create_default_context()
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE
        kwargs['ssl_context'] = context
        return super().init_poolmanager(*args, **kwargs)

# Replace requests' default HTTPAdapter with the custom SSLAdapter
requests.Session().mount('https://', SSLAdapter())
#######*************************************************
# # Function to parse user stories from the data string


# Function to create JIRA issue via REST API
def create_jira_issue(summary, description, tech_details, acceptance_criteria, epicid):
    url = JIRA_URL
    
    headers = {
        "Content-Type": "application/json"
    }
    auth = JIRA_AUTH
    bold_text = "**Acceptance Criteria :**"
    criteria = f"\n\n {bold_text}{acceptance_criteria}"
    bold_text = "**Technical Details :**"
    tech = f"\n\n {bold_text}{tech_details}"
    # print("\nsummary:", summary)
    # print("\ndescription:", description)
    # print("\ntech_details:", tech_details)
    # print("\nacceptance_criteria:", acceptance_criteria)

    payload = {
        "fields": {
            "project": {
                "id": "10284",
                "key": "TGP",
                "name": "TMO-GenAI POC"
            },
            "parent": {
                "key": epicid
            },
            "summary": summary,
            "description": description + tech + criteria,
            "issuetype": {
                "name": "Story"
            }
        }
    }
    print("\n\n\n\n payload ::", payload)
    response = requests.post(url, headers=headers, auth=auth, json=payload, verify=False)
    print("\n\n\n\  create jira response :: " ,response)
    # if response.status_code == 201:
    #     return response.json()['key'], response.status_code
    # else:
    #     return None, response.status_code
    if response.status_code == 201:
        return response.json().get("key"), response.status_code
    else:
        return None, response.status_code

# Function to parse user stories and extract relevant data
def parse_user_stories(data):
    # Ensure input is a string (join list elements if it's a list)
    if isinstance(data, list):
        data = "\n".join(data)
    
    user_stories = []
    index = 1

    while True:
        # Find the start of the current user story
        story_marker = f"User Story {index}:"
        start_index = data.find(story_marker)
        if start_index == -1:
            break  # No more stories found

        # Find the end of the current user story (start of the next one or end of data)
        next_story_marker = f"User Story {index + 1}:"
        end_index = data.find(next_story_marker)
        if end_index == -1:
            end_index = len(data)  # Last story in the input

        # Extract current user story text
        current_story_data = data[start_index:end_index].strip()

        # Helper function to extract a field between two markers
        def extract_field(field_name, next_field_name):
            field_start_index = current_story_data.find(f"{field_name}:")
            if field_start_index == -1:
                return "Not Specified"
            field_start_index += len(f"{field_name}:")
            field_end_index = current_story_data.find(f"{next_field_name}:", field_start_index)
            if field_end_index == -1:
                field_end_index = len(current_story_data)  # Last field
            return current_story_data[field_start_index:field_end_index].strip()

        # Extract fields
        summary = extract_field("Summary", "Description")
        description = extract_field("Description", "Technical Details")
        technical_details = extract_field("Technical Details", "Acceptance Criteria")
        acceptance_criteria = extract_field("Acceptance Criteria", "Sequence of execution and dependency")
        sequence_of_execution_and_dependency = extract_field("Sequence of execution and dependency", "")

        # Prepare story dictionary
        story_dict = {
            "summary": summary,
            "description": description,
            "technical_details": technical_details,
            "acceptance_criteria": acceptance_criteria,
            "sequence_of_execution_and_dependency": sequence_of_execution_and_dependency
        }
        user_stories.append(story_dict)

        # Move to the next user story index
        index += 1

    return user_stories


# Function to clean parsed data
def clean_data(data):
    keys_to_keep = ['summary', 'description', 'technical_details', 'acceptance_criteria']
   
    for item in data:
        for key in keys_to_keep:
            if key in item:
                item[key] = item[key].replace('\\"', '').replace('",', '').strip()
   
    return data


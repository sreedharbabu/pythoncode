from flask import Flask, render_template, request, jsonify
import openai
import json
import os
from flask_cors import CORS
from logs_info import log_message


FLASK_ENV='testing'
app = Flask(__name__)
CORS(app)
 
# Reading the config.json file and storing the values in a variables
#with open('webapp_analyze\config.json') as f: -- this is not working hence removed.
with open('config.json') as f:
    config = json.load(f)
    print("\n\n\n CONFIG :: ",config)

openai.api_key = config["OPEN_AI_KEY"]
openai.api_type = config["API_TYPE"]
openai.api_base = config["API_BASE"]
openai.api_version = config["API_VERSION"]
deployment_name = config["DEPLOYMENT_NAME"] 
model = config["MODEL"]
# Set up headers

headers = {
    'api-key': openai.api_key,
    'Content-Type': 'application/json'    
}

temperature=0.65
top_p=1
def openai_mocked_res(json_string,details,user_id, uuid):
    if(details == "analyze"):           #Feature analysis 
        json_data = json.loads(json_string)
        
        try:
            result = openai.ChatCompletion.create(
                messages=json_data,
                engine=deployment_name,
                temperature=temperature,
                top_p=top_p
            )
            res = result.choices[0].message['content']  # Access the message content
       
            completion_tokens = result.usage['completion_tokens']
            prompt_tokens = result.usage['prompt_tokens']
            total_tokens = result.usage['total_tokens']       
            log_message(user_id,uuid, f"Response for Gap Analysys : {res}", completion_tokens,prompt_tokens, total_tokens)
            return {"status": "success", "content": res}
    
        except openai.error.OpenAIError as e:
            # Handle known OpenAI errors (e.g., authentication errors, request errors)
            return {"status": "error", "message": str(e)}

        except Exception as e:
            # Handle other possible errors (e.g., network errors, unexpected exceptions)
            return {"status": "error", "message": "An unexpected error occurred: " + str(e)}
    
    elif(details == "rewrite"):         #REWRITE API
        json_data = json.loads(json_string)
        try:            
            result=openai.ChatCompletion.create(
            messages=json_data,
            engine=deployment_name,
            temperature=temperature,
            top_p=top_p
        )
            res = result.choices[0].message.content
            completion_tokens = result.usage['completion_tokens']
            prompt_tokens = result.usage['prompt_tokens']
            total_tokens = result.usage['total_tokens'] 
            log_message(user_id,uuid, f"Response for Re-write : {res}",completion_tokens, prompt_tokens, total_tokens)
            return {"status": "success", "content": res}
    
        except openai.error.OpenAIError as e:
            # Handle known OpenAI errors (e.g., authentication errors, request errors)
            return {"status": "error", "message": str(e)}

        except Exception as e:
            # Handle other possible errors (e.g., network errors, unexpected exceptions)
            return {"status": "error", "message": "An unexpected error occurred: " + str(e)}
          
    elif(details == "stepidentify"):        #stepidentify
        json_data = json.loads(json_string)
        try:
            result=openai.ChatCompletion.create(
            messages=json_data,
            engine=deployment_name,
            temperature=temperature,
            top_p=top_p
        )
            res = result.choices[0].message.content
            completion_tokens = result.usage['completion_tokens']
            prompt_tokens = result.usage['prompt_tokens']
            total_tokens = result.usage['total_tokens'] 
            log_message(user_id,uuid, f"Response for Step Identify: {res}", completion_tokens, prompt_tokens, total_tokens)
            return {"status": "success", "content": res}
    
        except openai.error.OpenAIError as e:
            # Handle known OpenAI errors (e.g., authentication errors, request errors)
            return {"status": "error", "message": str(e)}

        except Exception as e:
            # Handle other possible errors (e.g., network errors, unexpected exceptions)
            return {"status": "error", "message": "An unexpected error occurred: " + str(e)}
        
    elif(details == "userstory"):           #userstory
        json_data = json.loads(json_string)
        try:
            result=openai.ChatCompletion.create(
            messages=json_data,
            max_tokens = 10000,
            engine=deployment_name,
            temperature=temperature,
            top_p=top_p
        )
            res = result.choices[0].message.content
            completion_tokens = result.usage['completion_tokens']
            prompt_tokens = result.usage['prompt_tokens']
            total_tokens = result.usage['total_tokens'] 
            log_message(user_id,uuid, f"Response for User Story: {res}",completion_tokens,prompt_tokens, total_tokens)
            return {"status": "success", "content": res}
    
        except openai.error.OpenAIError as e:
            # Handle known OpenAI errors (e.g., authentication errors, request errors)
            return {"status": "error", "message": str(e)}

        except Exception as e:
            # Handle other possible errors (e.g., network errors, unexpected exceptions)
            return {"status": "error", "message": "An unexpected error occurred: " + str(e)}

    




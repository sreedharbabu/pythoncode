import logging
from datetime import datetime

# Configure logging
logging.basicConfig(filename='audit.log', level=logging.INFO, format='%(message)s')

def log_message(user_id, uuid, message, completion_tokens=None, prompt_tokens=None, total_tokens=None):
    log_entry = {
        "uuid": uuid,
        "user_id": user_id,
        "timestamp": datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        "message": message,
        "completion_tokens": completion_tokens,
        "prompt_tokens": prompt_tokens,
        "total_tokens": total_tokens
    }
    logging.info(log_entry)

    
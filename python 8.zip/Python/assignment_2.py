# # write a program to read a credit card number from the user and validate it 
# # length of card number should be exactly 16 digtis
# # cotains only digits
# # 1st digit should not be zero

cc_number = input("enter your card number :")

if len(cc_number) == 16:
    if cc_number.isdigit():
        if cc_number[0] != '0':
            print("its a valid card")
        else:
            print("Invlid card starts with  zero")
    else:
        print("Invalid card with non digit") 
else:
    print("Invalid card in correct length")


#python isntallation

pip install Flask
pip install openai
pip install requests
pip install flask_cors
pip install dotenv
pip install openai==0.28


